package com.example.potholepatrol;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.potholepatrol.ui.account.AccountFragment;
import com.example.potholepatrol.ui.add.AddFragment;
import com.example.potholepatrol.ui.explore.ExploreFragment;
import com.example.potholepatrol.ui.search.SearchFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.potholepatrol.databinding.PotholeNavigationBinding;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseUser;

public class Pothole_Navigation extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener {

    private PotholeNavigationBinding binding;
    public FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        user = intent.getParcelableExtra("User");
        binding = PotholeNavigationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnItemSelectedListener(this);
        navView.setSelectedItemId(R.id.navigation_explore);
    }

    private void replaceFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment_pothole_navigation, fragment).commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.navigation_explore) {
            ExploreFragment exploreFragment = new ExploreFragment();
            exploreFragment.User = user;
            replaceFragment(exploreFragment);
            return true;
        }
        else if(item.getItemId() == R.id.navigation_add)
        {
            AddFragment addFragment = new AddFragment();
            addFragment.User = user;
            replaceFragment(addFragment);
            return true;
        } else if (item.getItemId() == R.id.navigation_search)
        {
            SearchFragment searchFragment = new SearchFragment();
            searchFragment.User = user;
            replaceFragment(searchFragment);
            return true;
        } else if (item.getItemId() == R.id.navigation_account)
        {
            AccountFragment accountFragment = new AccountFragment();
            accountFragment.User = user;
            replaceFragment(accountFragment);
            return true;
        }
        return false;
    }

}
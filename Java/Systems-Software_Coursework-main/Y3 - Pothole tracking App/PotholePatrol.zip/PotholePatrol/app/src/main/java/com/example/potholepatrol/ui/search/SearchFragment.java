package com.example.potholepatrol.ui.search;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.potholepatrol.R;
import com.example.potholepatrol.databinding.FragmentSearchBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class SearchFragment extends Fragment implements OnMapReadyCallback {

    private FragmentSearchBinding binding;
    public FirebaseUser User;
    SearchView searchBar;
    TableLayout photoTable;
    FirebaseFirestore firestore;
    Fragment potHolLoc;
    FusedLocationProviderClient client;
    GoogleMap mMap;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSearchBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        potHolLoc = new Fragment();
        firestore = FirebaseFirestore.getInstance();
        searchBar = root.findViewById(R.id.SearchBar);
        photoTable = root.findViewById(R.id.PhotoTable);
        CollectionReference PhotoLocations = firestore.collection("PhotoLocation");
        final String[] barCont = new String[1];
        PhotoLocations.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                Log.i("PHOTOLOCATION_SUCCESS", "Successfully read photo location data");
                searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String s) {
                        barCont[0] = s.toLowerCase();
                        List<DocumentSnapshot> photoLocationDocs = queryDocumentSnapshots.getDocuments();
                        photoTable.removeAllViewsInLayout();
                        final boolean[] found = {false};
                        for (int i = 0 ; i < photoLocationDocs.size() ; i ++)
                        {
                            //DocumentSnapshot photoLoc = photoLocationDocs.get(i);
                            int finalI = i;
                            firestore.collection("Users").document(photoLocationDocs.get(i).getString("UserID")).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                    String UserDisp = documentSnapshot.getString("Name");
                                    DocumentSnapshot potHolPhoto = photoLocationDocs.get(finalI);
                                    LatLng PotHolLoc = new LatLng(potHolPhoto.getGeoPoint("Location").getLatitude(),photoLocationDocs.get(finalI).getGeoPoint("Location").getLongitude());
                                    if (UserDisp.toLowerCase().contains(s.toLowerCase().trim()))
                                    {
                                        TableRow photoRow = new TableRow(getContext());
                                        ImageView photoImg = new ImageView(photoRow.getContext());
                                        photoImg.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                                        Uri photouri = Uri.parse(potHolPhoto.getString("PotholeImage"));
                                        ViewGroup.LayoutParams layoutParams = photoImg.getLayoutParams();
                                        layoutParams.width = 500;
                                        layoutParams.height = 500;
                                        photoImg.setRotation(90);
                                        photoImg.setLayoutParams(layoutParams);
                                        TextView UserName = new TextView(photoRow.getContext());
                                        UserName.setTextSize(24);
                                        UserName.setTextColor(Color.WHITE);
                                        UserName.setGravity(Gravity.CENTER);
                                        photoImg.setImageURI(photouri);
                                        //mMap.moveCamera(CameraUpdateFactory.newLatLng(PotHolLoc));
                                        //mMap.addMarker(new MarkerOptions().position(PotHolLoc).title("You are here"));
                                        //mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(PotHolLoc, 15));
                                        UserName.setText(UserDisp);
                                        photoRow.removeAllViews();
                                        photoRow.addView(photoImg);
                                        photoRow.addView(UserName);
                                        photoRow.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                Intent detailIntent = new Intent(getActivity(), DetailSearch.class);
                                                detailIntent.putExtra("PhotoLocationID", potHolPhoto.getId());
                                                Log.i("SELECTED PHOTO ID", potHolPhoto.getId());
                                                detailIntent.putExtra("Username", UserDisp);
                                                startActivity(detailIntent);
                                            }
                                        });
                                        photoTable.addView(photoRow);
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.e("FIREBASE_READ_ERROR", "Unable to read firebase data: " + e);
                                    Toast.makeText(getContext(),  "Unable to read user data", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (photoTable.getChildCount() == 0 && barCont[0] != null)
                                    {
                                        TableRow photoRow = new TableRow(getContext());
                                        TextView UserName = new TextView(photoRow.getContext());
                                        UserName.setText("No results for \"" + barCont[0] + "\"");
                                        UserName.setTextSize(24);
                                        UserName.setTextColor(Color.WHITE);
                                        UserName.setGravity(Gravity.CENTER);
                                        photoRow.addView(UserName);
                                        photoTable.addView(photoRow);
                                    }
                                }
                            });
                        }
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String s) {
                        return false;
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e("PHOTOLOCATION_FAILURE", "Failed to read photo location data: " + e);
            }
        });

        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //SupportMapFragment mapFragment = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.map);
        //SupportMapFragment mapFragment = (SupportMapFragment) potHolLoc;
        //mapFragment.getMapAsync(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        client = LocationServices.getFusedLocationProviderClient(getActivity());
    }
}
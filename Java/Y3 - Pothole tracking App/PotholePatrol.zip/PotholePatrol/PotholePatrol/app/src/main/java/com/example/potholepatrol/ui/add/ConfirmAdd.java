package com.example.potholepatrol.ui.add;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.potholepatrol.Pothole_Navigation;
import com.example.potholepatrol.R;
import com.example.potholepatrol.databinding.ConfirmAddBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

import java.util.HashMap;
import java.util.Map;

public class ConfirmAdd extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mMap;
    LatLng PotholLocation;
    Uri photoUri;
    View view;
    Button ConfirmBtn, BackBtn;
    View miniMap;
    ImageView imageView;
    CheckBox repairedBox;
    FirebaseUser User;
    ConfirmAddBinding binding;
    FusedLocationProviderClient client;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ConfirmAddBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent photoIntent = getIntent();
        User = photoIntent.getParcelableExtra("User");
        photoUri = photoIntent.getParcelableExtra("PhotoUri");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.minimap);
        mapFragment.getMapAsync(this);
        imageView = findViewById(R.id.PreviewImage);
        miniMap = findViewById(R.id.minimap);
        ConfirmBtn = findViewById(R.id.ConfirmPhotoBtn);
        BackBtn = findViewById(R.id.BackButton);
        repairedBox = findViewById(R.id.RepairedCheckBox);

        imageView.setImageURI(photoUri);
        // Location lab from MPA
        Log.i("IMAGE_URI", photoUri.toString());
        ConfirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SavePhotoToFb();
                Intent intent = new Intent(ConfirmAdd.this, Pothole_Navigation.class);
                intent.putExtra("User", User);
                startActivity(intent);
            }
        });
        BackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConfirmAdd.this, Pothole_Navigation.class);
                intent.putExtra("User", User);
                startActivity(intent);
            }
        });
    }



    @Override
    public void onMapReady(@NonNull GoogleMap googleMap)
    {
        mMap = googleMap;
        client = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //Permission has not been granted
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    101);
            PotholLocation = new LatLng(0, 0);
        } else {
            //Permission has been granted
            client.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                PotholLocation = new LatLng(location.getLatitude(), location.getLongitude());
                                Log.i("GPS_LOCATION_FOUND_MINI", "GPS location was found");
                                // Logic to handle location object
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(PotholLocation));
                                mMap.addMarker(new MarkerOptions().position(PotholLocation).title("Pothole Location"));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(PotholLocation, 15));

                            } else {
                                Toast.makeText(getApplicationContext(), "GPS Location is null", Toast.LENGTH_SHORT).show();
                                Log.e("GPS_LOCATION_NULL", "GPS NUll");
                                PotholLocation = new LatLng(location.getLatitude(), location.getLongitude());

                            }
                        }
                    }).addOnFailureListener(this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("GPS_FAILED", e.getMessage());
                        }
                    });
        }
    }

    void SavePhotoToFb()
    {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> data = new HashMap<>();
        GeoPoint PotLoc = new GeoPoint(PotholLocation.latitude, PotholLocation.longitude);
        data.put("UserID", User.getUid());
        data.put("Location", PotLoc);
        data.put("PotholeImage", photoUri.toString());
        data.put("Repaired", repairedBox.isChecked());
        db.collection("PhotoLocation").document(User.getUid() + photoUri.toString().split("/")[photoUri.toString().split("/").length-1]).set(data).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("USER_DATA_WRITING", "SUCCESS " + User.getUid() + photoUri.toString().split("/")[photoUri.toString().split("/").length-1]);
                Toast.makeText(getApplicationContext(), "Photo saved to database", Toast.LENGTH_SHORT).show();
            }

        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e("USER_DATA_WRITING", "FAILURE " + e);
            }
        });
    }

    @Override
    protected void onDestroy() {
        getIntent().putExtra("User", User);
        super.onDestroy();
    }
}
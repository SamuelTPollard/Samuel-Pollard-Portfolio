package com.example.potholepatrol.ui.explore;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.example.potholepatrol.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class ExploreFragment extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    View view;
    FusedLocationProviderClient client;
    public LatLng LastLoc;
    Button RecenterBtn;
    public FirebaseUser User;
    FirebaseFirestore firestore;
    Bundle ViewBundle;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ViewBundle = savedInstanceState;
        view = inflater.inflate(R.layout.fragment_explore, container, false);
        SupportMapFragment mapFragment = (SupportMapFragment) this.getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        RecenterBtn = view.findViewById(R.id.RecenterButton);
        firestore = FirebaseFirestore.getInstance();
        RecenterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final LatLng[] UpLatLng = new LatLng[1];
                // Location lab from MPA
                client = LocationServices.getFusedLocationProviderClient(getActivity());
                if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    //Permission has not been granted
                    ActivityCompat.requestPermissions(getActivity(),
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION},
                            101);
                    UpLatLng[0] = new LatLng(0, 0);
                    LastLoc = UpLatLng[0];
                } else {
                    //Permission has been granted
                    client.getLastLocation()
                            .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                                @Override
                                public void onSuccess(Location location) {
                                    // Got last known location. In some rare situations this can be null.
                                    if (location != null) {
                                        UpLatLng[0] = new LatLng(location.getLatitude(), location.getLongitude());
                                        LastLoc = UpLatLng[0];
                                        CameraPosition newPos = new CameraPosition(UpLatLng[0], 15, 0, 0);
                                        Log.i("GPS_LOCATION_FOUND", "GPS location was found");
                                        // Logic to handle location object
                                        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(newPos));

                                    } else {
                                        Toast.makeText(getActivity(), "GPS Location is null", Toast.LENGTH_SHORT).show();
                                        Log.e("GPS_LOCATION_NULL", "GPS NUll");
                                        UpLatLng[0] = new LatLng(0, 0);

                                    }
                                }
                            }).addOnFailureListener(getActivity(), new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.e("GPS_FAILED", e.getMessage());
                                    UpLatLng[0] = new LatLng(0, 0);
                                }
                            });

                }
            }
        });
        return view;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        //locationTracking = new LocationTracking(getActivity().getApplicationContext());
        mMap = googleMap;
        client = LocationServices.getFusedLocationProviderClient(getActivity());

        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //Permission has not been granted
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    101);
        } else {
            //Permission has been granted
            client.getLastLocation()
                    .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                LatLng LastLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                                // Logic to handle location object
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(LastLatLng));
                                float[] hsv = new float[3];
                                Color.colorToHSV(Color.parseColor("#4D4D4D"), hsv);
                                mMap.addMarker(new MarkerOptions().position(LastLatLng).title("You are here").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LastLatLng, 15));
                            } else {
                                Toast.makeText(getActivity(), "GPS Location is null", Toast.LENGTH_SHORT).show();
                                Log.e("GPS_LOCATION_NULL", "GPS NUll");
                            }
                        }
                    }).addOnFailureListener(getActivity(), new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("GPS_FAILED", e.getMessage());
                        }
                    });
            CollectionReference PhotoLocations = firestore.collection("PhotoLocation");
            PhotoLocations.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                @Override
                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                    Log.i("PHOTOLOCATION_SUCCESS", "Successfully read photo location data");
                    List<DocumentSnapshot> photoLocationDocs = queryDocumentSnapshots.getDocuments();
                    for (int i = 0; i < photoLocationDocs.size(); i++) {
                        String[] UserDisp = new String[1];
                        DocumentSnapshot photoLoc = photoLocationDocs.get(i);
                        firestore.collection("Users").document(photoLoc.getString("UserID")).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                GeoPoint PotLoc = photoLoc.getGeoPoint("Location");
                                BitmapDescriptor markCol;
                                UserDisp[0] = documentSnapshot.getString("Name");
                                if (photoLoc.getBoolean("Repaired"))
                                {
                                    markCol = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);
                                    if (photoLoc.getString("UserID").equals(User.getUid()))
                                    {
                                        mMap.addMarker(new MarkerOptions().position(new LatLng(PotLoc.getLatitude(), PotLoc.getLongitude()) ).title(UserDisp[0]).icon(markCol));
                                    }

                                }
                                else
                                {
                                    markCol = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED);
                                    mMap.addMarker(new MarkerOptions().position(new LatLng(PotLoc.getLatitude(), PotLoc.getLongitude()) ).title(UserDisp[0]).icon(markCol));
                                }

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("FIREBASE_READ_ERROR", "Unable to read firebase data: " + e);
                                Toast.makeText(getContext(), "Unable to read user data", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            });
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //TODO: What to do if the permission has been granted?
                Toast.makeText(getActivity(), "Permission has been granted.", Toast.LENGTH_SHORT).show();
            } else {
                //TODO: What to do if the permission has been denied?
                Toast.makeText(getActivity(), "Permission has NOT been granted.", Toast.LENGTH_SHORT).show();
            }
        }

    }


}

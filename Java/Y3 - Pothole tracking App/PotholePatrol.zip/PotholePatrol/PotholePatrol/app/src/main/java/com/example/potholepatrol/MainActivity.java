package com.example.potholepatrol;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    Button CreateAccountButton, SignInButton;
    EditText EmailEditText, PasswordEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mAuth = FirebaseAuth.getInstance();
        EmailEditText = findViewById(R.id.editTextEmail);
        PasswordEditText = findViewById(R.id.editTextPassword);
        CreateAccountButton = findViewById(R.id.CreateAccountButton);
        CreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CreateAccount.class);
                startActivity(intent);
            }
        });
        SignInButton = findViewById(R.id.LoginButton);
        SignInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (EmailEditText.getText().toString().isEmpty() || PasswordEditText.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "All fields must be filled", Toast.LENGTH_SHORT).show();
                } else {
                    mAuth.signInWithEmailAndPassword(EmailEditText.getText().toString(), PasswordEditText.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                FirebaseUser user = mAuth.getCurrentUser();

                                Toast.makeText(MainActivity.this, "Sign in success", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, Pothole_Navigation.class);
                                intent.putExtra("User", user);
                                Log.d("USER_DATA_GETTINNG", "UId: " + user.getUid());
                                startActivity(intent);
                            } else if (task.getException().getClass().toString().equals("class com.google.firebase.auth.FirebaseAuthInvalidCredentialsException")) {
                                Toast.makeText(MainActivity.this, "Incorrect email or password", Toast.LENGTH_SHORT).show();
                            } else if (task.getException().getClass().toString().equals("class com.google.firebase.FirebaseNetworkException")) {
                                Toast.makeText(MainActivity.this, "Check Network connection", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.d("FIREBASE_ERROR", task.getException().toString());
                                Toast.makeText(MainActivity.this, "Sign in failed: " + task.getException().getClass().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
}
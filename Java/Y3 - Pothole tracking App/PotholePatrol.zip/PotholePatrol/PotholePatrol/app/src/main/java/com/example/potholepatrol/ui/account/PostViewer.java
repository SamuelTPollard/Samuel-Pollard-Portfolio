package com.example.potholepatrol.ui.account;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.potholepatrol.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.Filter;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class PostViewer extends AppCompatActivity  {

    FirebaseFirestore firestore;
    TableLayout postTable;
    String Username;
    FirebaseUser User;
    String UserID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firestore = FirebaseFirestore.getInstance();
        User = getIntent().getParcelableExtra("User");
        EdgeToEdge.enable(this);
        setContentView(R.layout.post_viewer);

        firestore.collection("Users").document(User.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
             @Override
             public void onSuccess(DocumentSnapshot documentSnapshot) {
                 Username = documentSnapshot.getString("Name");
                 UserID = documentSnapshot.getString("UserID");
             }
         });
        firestore = FirebaseFirestore.getInstance();
        postTable = findViewById(R.id.PostTable);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        CollectionReference PhotoLocations = firestore.collection("PhotoLocation");
        PhotoLocations.where(Filter.equalTo("UserID", User.getUid())).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                List<DocumentSnapshot> photoLocationDocs = queryDocumentSnapshots.getDocuments();
                if (!photoLocationDocs.isEmpty()) {
                    Log.i("PHOTOLOCATION_SUCCESS", "Successfully read photo location data");
                    for (int i = 0; i < photoLocationDocs.size(); i++) {
                        DocumentSnapshot photoLoc = photoLocationDocs.get(i);
                        TableRow photoRow = new TableRow(getApplicationContext());
                        ImageView photoImg = new ImageView(photoRow.getContext());
                        photoImg.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                        Uri photouri = Uri.parse(photoLoc.getString("PotholeImage"));
                        ViewGroup.LayoutParams layoutParams = photoImg.getLayoutParams();
                        layoutParams.width = 800;
                        layoutParams.height = 800;
                        photoImg.setForegroundGravity(Gravity.CENTER);
                        photoImg.setLayoutParams(layoutParams);
                        photoImg.setRotation(90);
                        photoImg.setImageURI(photouri);
                        photoRow.removeAllViews();
                        photoRow.addView(photoImg);
                        photoRow.setGravity(Gravity.CENTER);
                        photoRow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent detailIntent = new Intent(getApplicationContext(), PostManager.class);
                                detailIntent.putExtra("PhotoLocationID", photoLoc.getId());
                                detailIntent.putExtra("User", User);
                                startActivity(detailIntent);
                            }
                        });
                        postTable.addView(photoRow);
                    }
                }
                else
                {
                    TableRow photoRow = new TableRow(getApplicationContext());
                    TextView UserName = new TextView(photoRow.getContext());
                    UserName.setText("No posts yet");
                    UserName.setTextSize(24);
                    UserName.setTextColor(Color.WHITE);
                    UserName.setGravity(Gravity.CENTER);
                    photoRow.addView(UserName);
                    postTable.addView(photoRow);
                }
            }

        });
    }

    @Override
    protected void onDestroy() {
        getIntent().putExtra("User", User);
        super.onDestroy();
    }
}
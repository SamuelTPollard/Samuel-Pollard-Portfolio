package com.example.potholepatrol.ui.search;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.example.potholepatrol.Pothole_Navigation;
import com.example.potholepatrol.R;
import com.example.potholepatrol.databinding.DetailSearchBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class DetailSearch extends FragmentActivity implements OnMapReadyCallback {

    LatLng photoLoc;
    String UserName;
    Uri PhotoUri;
    boolean repaired;
    DetailSearchBinding binding;
    FusedLocationProviderClient client;
    GoogleMap mMap;
    ImageView PhotHolImg;
    TextView UserNameView;
    Button BackArrow;
    FirebaseUser User;
    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DetailSearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        firestore = FirebaseFirestore.getInstance();
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.potholmap);
        mapFragment.getMapAsync(this);

        Intent detIntent = getIntent();
        User = detIntent.getParcelableExtra("User");
        firestore.collection("PhotoLocation").document(detIntent.getStringExtra("PhotoLocationID")).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                UserName = detIntent.getStringExtra("Username");
                photoLoc = new LatLng(documentSnapshot.getGeoPoint("Location").getLatitude(), documentSnapshot.getGeoPoint("Location").getLongitude());
                PhotoUri = Uri.parse(documentSnapshot.getString("PotholeImage"));
                repaired = documentSnapshot.getBoolean("Repaired");
                PhotHolImg = findViewById(R.id.PotholeImage);
                PhotHolImg.setImageURI(PhotoUri);
                UserNameView = findViewById(R.id.UserNameDisp);
                UserNameView.setText(UserName);
            }
        });

        BackArrow = findViewById(R.id.BackButtonSrh);
        BackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DetailSearch.this, Pothole_Navigation.class);
                intent.putExtra("User", User);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        client = LocationServices.getFusedLocationProviderClient(this);
        BitmapDescriptor markCol;
        if (repaired)
        {
            markCol = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);
        }
        else
        {
            markCol = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED);
        }
        mMap.addMarker(new MarkerOptions().position(photoLoc).title(UserName).icon(markCol));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(photoLoc));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(photoLoc, 15));
    }

    @Override
    protected void onDestroy() {
        getIntent().putExtra("User", User);
        super.onDestroy();
    }
}
package com.example.potholepatrol.ui.account;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.potholepatrol.MainActivity;
import com.example.potholepatrol.R;
import com.example.potholepatrol.databinding.FragmentAccountBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class AccountFragment extends Fragment {

    private FragmentAccountBinding binding;
    public FirebaseUser User;
    FirebaseFirestore firestore;
    String StartName;
    EditText NameTextView, NewPassword, ConfirmPassword, CurrentPassword;
    TextView EmailTextView;
    Button ConfirmButton, PostViewButton, DeleteAccountBtn;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        firestore = FirebaseFirestore.getInstance();

        binding = FragmentAccountBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        NameTextView = root.findViewById(R.id.DisplayNameDisplay);
        EmailTextView = root.findViewById(R.id.EmailDisplay);
        CurrentPassword = root.findViewById(R.id.OldPassword);
        NewPassword = root.findViewById(R.id.NewPassword);
        ConfirmPassword = root.findViewById(R.id.ConfirmNewPassword);
        ConfirmButton = root.findViewById(R.id.ConfirmButton);
        PostViewButton = root.findViewById(R.id.PostViewBtn);
        // Getting the current user's information from the firestore to add into the text fields
        firestore.collection("Users").document(User.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                StartName = documentSnapshot.getString("Name");
                NameTextView.setText(documentSnapshot.getString("Name"));
                EmailTextView.setText(documentSnapshot.getString("Email"));
                ConfirmButton.setVisibility(View.VISIBLE);
            }
            }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e("FIREBASE_READ_ERROR", "Unable to read firebase data: " + e);
                        Toast.makeText(getContext(),  "Unable to read user data", Toast.LENGTH_SHORT).show();
                    }
            }).addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        task.getResult();
                    }
            });
        ConfirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Authentication of the user to allow their data and login information to be updated
                if (!CurrentPassword.getText().toString().isEmpty()) {
                    AuthCredential credential = EmailAuthProvider
                            .getCredential(User.getEmail(), CurrentPassword.getText().toString());
                    User.reauthenticate(credential)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            if (!NameTextView.getText().toString().isEmpty() && !NameTextView.getText().toString().equals(StartName)) {
                                // Getting users firebase store data
                                DocumentReference updateUser = firestore.collection("Users").document(User.getUid());
                                // Beginning update data task in firestore
                                updateUser.update("Name", NameTextView.getText().toString()).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Log.i("FIRESTORE_DISPLAY_NAME_UPDATE_SUCCESS", "Display name updated");
                                        UserProfileChangeRequest updateName = new UserProfileChangeRequest.Builder()
                                                .setDisplayName(NameTextView.getText().toString()).build();
                                        User.updateProfile(updateName)
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void unused) {
                                                        StartName = NameTextView.getText().toString();
                                                        Log.i("FIREAUTH_USER_UPDATE_SUCCESS", "Display name now: " + NameTextView.getText().toString());
                                                        Toast.makeText(getContext(), "Display name updated", Toast.LENGTH_SHORT).show();
                                                    }
                                                }).addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        // Informing user and log of failure
                                                        Toast.makeText(getContext(), "Display name update failed", Toast.LENGTH_SHORT).show();
                                                        Log.e("FIREAUTH_USER_FAILURE", e.toString());
                                                    }
                                                });
                                    }
                                }).addOnFailureListener(new OnFailureListener()
                                {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e("FIRESTORE_DISPLAY_NAME_ERROR", "Display name update error: " + e);
                                    }
                                });
                            }
                            else if (!NewPassword.getText().toString().isEmpty() && !ConfirmPassword.getText().toString().isEmpty()) {
                                if (NewPassword.getText().toString().equals(ConfirmPassword.getText().toString())) {
                                    User.updatePassword(NewPassword.getText().toString()).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            Toast.makeText(getContext(), "Password updated", Toast.LENGTH_SHORT).show();
                                            Log.i("FIREAUTH_SUCCESS_PASSWORD", "Password updated successfully");
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(getContext(), "Password update failed", Toast.LENGTH_SHORT).show();
                                            Log.e("FIREAUTH_FAILURE_PASSWORD", "Password update failure " + e.toString());
                                        }
                                    });
                                }
                                else
                                {
                                    Toast.makeText(getContext(), "Passwords must match", Toast.LENGTH_SHORT).show();
                                }
                            }
                            else
                            {
                                Toast.makeText(getContext(), "All fields match current user data", Toast.LENGTH_SHORT);
                            }

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("FIREAUTH_REAUTHENTICATION_FAILURE", e.toString());
                            Toast.makeText(getContext(), "Current password incorrect", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    Toast.makeText(getContext(), "Please enter old password", Toast.LENGTH_SHORT).show();
                }
            }
        });
        PostViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PostViewer.class);
                intent.putExtra("User", User);
                startActivity(intent);
            }
        });
        DeleteAccountBtn = root.findViewById(R.id.DeleteAccBtn);
        DeleteAccountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Authentication of user to allow user data to be deleted
                if (!CurrentPassword.getText().toString().isEmpty()) {
                    AuthCredential credential = EmailAuthProvider
                            .getCredential(User.getEmail(), CurrentPassword.getText().toString());
                    User.reauthenticate(credential).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            String UserID = User.getUid();
                            List<String> PotholesToDelete = new ArrayList<>();
                            // Getting all photoLocation documents
                            CollectionReference PhotoLocations = firestore.collection("PhotoLocation");
                            PhotoLocations.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                              @Override
                              public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                  // Getting all of the photo locations which below to the user to be deleted
                                  List<DocumentSnapshot> photoLocationDocs = queryDocumentSnapshots.getDocuments();
                                  for (int i = 0; i < photoLocationDocs.size(); i++) {
                                      if (photoLocationDocs.get(i).getString("UserID").equals(User.getUid())) {
                                          PotholesToDelete.add(photoLocationDocs.get(i).getId());
                                      }
                                  }
                                  // Looping through all photoLocations belonging to the user and deleting them
                                  for (String potID :PotholesToDelete)
                                  {
                                      firestore.collection("PhotoLocation").document(potID).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                          @Override
                                          public void onSuccess(Void unused) {
                                              Log.i("USER_POST_DELETE", "Delete success");
                                          }
                                      }).addOnFailureListener(new OnFailureListener() {
                                          @Override
                                          public void onFailure(@NonNull Exception e) {
                                              Log.e("USER_POST_DELETE_FAILURE", "Delete failure " + e);
                                          }
                                      });
                                  }
                                    // Removing the user from the firebase authenticaton, but only if it was successfully removed from the firebase store
                                    User.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            Log.i("USER_DELETE_SUCCESS", NameTextView.getText().toString());
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.e("USER_DELETE_FAILURE", NameTextView.getText().toString());
                                        }
                                    }).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            firestore.collection("Users").document(UserID).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    Log.i("FIRESTORE_USER_DELETED", "Success");
                                                    Intent intent = new Intent(getContext(), MainActivity.class);
                                                    startActivity(intent);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Log.e("FIRESTORE_USER_DELETE_FAILURE", e.toString());
                                                }
                                            });
                                        }
                                    });
                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getContext(), "Current password incorrect", Toast.LENGTH_SHORT);
                        }
                    });

                }
                else
                {
                    Toast.makeText(getContext(), "Enter current password to delete account", Toast.LENGTH_SHORT).show();;
                }
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
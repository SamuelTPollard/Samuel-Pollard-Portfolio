package com.example.potholepatrol;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CreateAccount extends AppCompatActivity {

    private FirebaseAuth mAuth;
    public Button CreateAccountButton;
    FirebaseUser User;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.create_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        CreateAccountButton = findViewById(R.id.CreateAccountButton);
        mAuth = FirebaseAuth.getInstance();
        CreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CreateAccountButtonPressed();
            }
        });
    }

    public void CreateAccountButtonPressed() {
        EditText NameEditText = findViewById(R.id.editTextName);
        EditText EmailEditText = findViewById(R.id.editTextEmail);
        EditText PasswordEditText = findViewById(R.id.editTextPassword);
        EditText ConfPasswordEditText = findViewById(R.id.editTextPasswordConf);
        if (NameEditText.getText().toString().isEmpty() || EmailEditText.getText().toString().isEmpty() || PasswordEditText.getText().toString().isEmpty() || ConfPasswordEditText.getText().toString().isEmpty()) {
            Toast.makeText(CreateAccount.this, "All fields must be filled", Toast.LENGTH_SHORT).show();
        } else if (!PasswordEditText.getText().toString().equals(ConfPasswordEditText.getText().toString())) {
            Toast.makeText(CreateAccount.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
        } else {
            mAuth.createUserWithEmailAndPassword(EmailEditText.getText().toString(), PasswordEditText.getText().toString()).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                // Checks whether or not the sign is succeeded
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) // Success, move to main page
                    {
                        User = mAuth.getCurrentUser();
                        Toast.makeText(getApplicationContext(), "Welcome to PotholePatrol " + NameEditText.getText().toString(), Toast.LENGTH_SHORT).show();
                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        Map<String, Object> data = new HashMap<>();
                        data.put("UserID", mAuth.getCurrentUser().getUid());
                        data.put("Name", NameEditText.getText().toString());
                        data.put("Email", EmailEditText.getText().toString());
                        db.collection("Users").document(User.getUid()).set(data).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Log.d("USER_DATA_WRITING", "SUCCESS " + User.getUid());
                                    }

                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("USER_DATA_WRITING", "FAILURE " + e);
                            }
                        });
                        Intent intent = new Intent(CreateAccount.this, Pothole_Navigation.class);
                        intent.putExtra("User", User);
                        startActivity(intent);
                    } else {
                        switch (task.getException().getClass().toString()) {
                            case "class com.google.firebase.auth.FirebaseAuthUserCollisionException": // Email already in use
                                Toast.makeText(CreateAccount.this, "Email  " + EmailEditText.getText().toString() + " is already in use", Toast.LENGTH_SHORT).show();
                                Log.w("FIREBASE_ERROR_EMAIL", task.getClass().toString());
                                break;

                            case "class com.google.firebase.auth.FirebaseAuthWeakPasswordException": // Password too weak (short)
                                Toast.makeText(CreateAccount.this, "Password is too short, must be at least six characters", Toast.LENGTH_SHORT).show();
                                Log.w("FIREBASE_ERROR_PASSWORD", task.getException().toString());
                                break;

                            case "class com.google.firebase.auth.FirebaseApiNotAvailableException": // Wi-Fi/ Firebase connection error
                                Toast.makeText(CreateAccount.this, "Connection error, please check Wi-Fi connection", Toast.LENGTH_SHORT).show();
                                Log.w("FIREBASE_ERROR_CONNECTION", task.getException().toString());
                                break;

                            case "class com.google.firebase.authFirebaseAuthInvalidUserException":
                                Toast.makeText(CreateAccount.this, "Invalid email format" + task.getException().toString(), Toast.LENGTH_SHORT).show();
                                Log.w("FIREBASE_ERROR_EMAIL", task.getException().toString());
                                break;

                            case "class com.google.firebase.FirebaseNetworkException":
                                Toast.makeText(CreateAccount.this, "Check network connection", Toast.LENGTH_SHORT).show();
                                Log.w("NETWORK_CONNECTION_ERROR", task.getException().toString());

                            default: // Other uncaught error type
                                Toast.makeText(CreateAccount.this, "Create account fail" + task.getException().toString(), Toast.LENGTH_SHORT).show();
                                Log.w("FIREBASE_ERROR_OTHER", task.getException().toString());
                                break;
                        }
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        getIntent().putExtra("User", User);
        super.onDestroy();
    }
}
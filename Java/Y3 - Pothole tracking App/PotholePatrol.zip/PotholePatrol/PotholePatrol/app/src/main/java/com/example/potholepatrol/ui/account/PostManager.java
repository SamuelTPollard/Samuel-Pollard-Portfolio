package com.example.potholepatrol.ui.account;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentActivity;

import com.example.potholepatrol.Pothole_Navigation;
import com.example.potholepatrol.R;
import com.example.potholepatrol.databinding.PostManagerBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

public class PostManager extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mMap;
    PostManagerBinding binding;
    FusedLocationProviderClient client;
    boolean repaired;
    LatLng photoLocation = new LatLng(0, 0), LastClick;
    Uri PhotoUri;
    FirebaseFirestore firestore;
    BitmapDescriptor markCol;
    ImageView PotHolePhoto;
    TextView LatitudeText, LongitudeText;
    Button BackBtn, UpdateBtn, SubmitBtn, DeleteBtn;
    FirebaseUser User;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        User = getIntent().getParcelableExtra("User");
        binding = PostManagerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        //setContentView(R.layout.post_manager);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.potholmapMng);
        mapFragment.getMapAsync(this);
        LatitudeText = findViewById(R.id.LatitudeText);
        LongitudeText = findViewById(R.id.LongitudeText);
        firestore = FirebaseFirestore.getInstance();
        PotHolePhoto = findViewById(R.id.PotholeImageMng);
        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        firestore.collection("PhotoLocation").document(getIntent().getStringExtra("PhotoLocationID")).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot)
            {
                Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
                photoLocation = new LatLng(documentSnapshot.getGeoPoint("Location").getLatitude(), documentSnapshot.getGeoPoint("Location").getLongitude());
                LastClick = photoLocation;
                LatitudeText.setText(String.valueOf(photoLocation.latitude).substring(0, 7));
                LongitudeText.setText(String.valueOf(photoLocation.longitude).substring(0, 7));
                PhotoUri = Uri.parse(documentSnapshot.getString("PotholeImage"));
                Log.i("PHOTO_LOCATION_MANAGER", photoLocation.toString());
                repaired = documentSnapshot.getBoolean("Repaired");
                PotHolePhoto.setImageURI(PhotoUri);
                LatitudeText = findViewById(R.id.LatitudeText);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "FAILURE", Toast.LENGTH_SHORT).show();
                Log.e("READ_ERROR", e.toString());
            }
        });
        BackBtn = findViewById(R.id.BackButtonMng);
        BackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Pothole_Navigation.class);
                intent.putExtra("User", User);
                startActivity(intent);
            }
        });
        SubmitBtn = findViewById(R.id.SubmitBtn);
        SubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firestore.collection("PhotoLocation").document(getIntent().getStringExtra("PhotoLocationID")).update("Location", new GeoPoint(photoLocation.latitude, photoLocation.longitude)).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.i("POTHOLE_LOCATION_UPDATED", "Success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Update pothole location failed", Toast.LENGTH_SHORT).show();
                        Log.e("POTHOLE_LOCATION_UPDATE_FAILED", e.toString());
                    }
                });
                firestore.collection("PhotoLocation").document(getIntent().getStringExtra("PhotoLocationID")).update("Repaired", repaired).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.i("POTHOLE_REPAIRED_UPDATED", "Success");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Update pothole repaired failed", Toast.LENGTH_SHORT).show();
                        Log.e("POTHOLE_REPAIRED_UPDATE_FAILED", e.toString());
                    }
                });
                Intent intent = new Intent(getApplicationContext(), Pothole_Navigation.class);
                intent.putExtra("User", User);
                startActivity(intent);
            }
        });
        DeleteBtn = findViewById(R.id.DeletePostBtn);
        DeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                firestore.collection("PhotoLocation").document(getIntent().getStringExtra("PhotoLocationID")).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successfully deleted post", Toast.LENGTH_SHORT).show();
                        Log.i("POST_DELETED", "Success");
                        Intent intent = new Intent(getApplicationContext(), Pothole_Navigation.class);
                        intent.putExtra("User", User);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Post delete failed", Toast.LENGTH_SHORT).show();
                        Log.e("POST_DELETE_FAILED", e.toString());
                    }
                });
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        Log.e("MAPSREADY", "");
        mMap = googleMap;
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                LastClick = latLng;
            }
        });
        UpdateBtn = findViewById(R.id.UpdateBtn);
        UpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                photoLocation = LastClick;
                LatitudeText.setText(String.valueOf(photoLocation.latitude).substring(0, 7));
                LongitudeText.setText(String.valueOf(photoLocation.longitude).substring(0, 7));
                CheckBox repCheck = findViewById(R.id.RepairedCheckBoxMng);
                repaired = repCheck.isChecked();
                if (repaired)
                {
                    markCol = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);
                }
                else
                {
                    markCol = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED);
                }
                mMap.clear();
                mMap.addMarker(new MarkerOptions().position(photoLocation).icon(markCol));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(photoLocation));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(photoLocation, 15));
            }
        });
        client = LocationServices.getFusedLocationProviderClient(this);
        mMap.addMarker(new MarkerOptions().position(photoLocation).icon(markCol));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(photoLocation));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(photoLocation, 15));

    }

    @Override
    protected void onDestroy() {
        getIntent().putExtra("User", User);
        super.onDestroy();
    }
}